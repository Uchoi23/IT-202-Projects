<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" 
    href="style.css">
</head>
<body>
    <img src = "Rhine_Lab-removebg-preview.png" alt = "Logo" style = "width: 90px; height = 60px; margin-left: 20px; position: relative; top: -15px;">
    <ul class="navbar">
        <li><a href="#">Who We Are</a></li>
        <li><a href="#">What We Offer</a></li>
        <li><a href="#">How We Do It</a></li>
        <li><a href="#">People & Values</a></li>
        <li><a href="#">Contact</a></li>
    </ul>
</body>
</html>
