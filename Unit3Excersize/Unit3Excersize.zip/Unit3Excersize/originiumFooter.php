<footer>
    <h4>
        <p>Raphael Holganza, 09/12/3022, OA-301-502, 
        Unit 3 In-Class Exercise
        </p>
    </h4>
    <h5>
        <section id = "Email">
            Email <a href = "mailto:rmh38@njit.edu"> rmh38@njit.edu</a> for inquiries
            regarding the course or scheduling.
        </section>
    </h5>
</footer>